//Miles Maltbia
//mmaltbia

package ds.cmu.cf;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import org.json.JSONObject;
import com.bumptech.glide.Glide;

public class TeamDataActivity extends AppCompatActivity {

    private ImageView teamLogo;
    private TextView teamDetails;
    private Button previousButton;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_data);

        teamLogo = findViewById(R.id.teamLogo);
        teamDetails = findViewById(R.id.teamDetails);
        previousButton = findViewById(R.id.previousButton);
        requestQueue = Volley.newRequestQueue(this);

        String team = getIntent().getStringExtra("team");
        fetchTeamData(team); //gets the team info from codespaces

        previousButton.setOnClickListener(v -> finish());
    }

    private void fetchTeamData(String team) {
        String url = "https://cuddly-happiness-7g79vj96rv3xj79-8080.app.github.dev/api/team/" + team;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try { //gets the info from the JSON response
                        String school = response.getString("school");
                        String conference = response.getString("conference");
                        String state = response.getJSONObject("location").getString("state");
                        String logoUrl = response.getJSONArray("logos").getString(0);
                        System.out.println("LOGO: " + logoUrl);
                        //prints the team info
                        teamDetails.setText("School: " + school + "\nConference: " + conference + "\nState: " + state);
                        Glide.with(this).load(logoUrl).into(teamLogo);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> error.printStackTrace()
        );

        requestQueue.add(request);
    }
}