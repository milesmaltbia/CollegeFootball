//Miles Maltbia
//mmaltbia

package ds.cmu.cf;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private EditText searchBar;
    private Button submitButton;
    private RequestQueue requestQueue;
    private String selectedTeam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.radioGroup);
        searchBar = findViewById(R.id.searchBar);
        submitButton = findViewById(R.id.submitButton);
        requestQueue = Volley.newRequestQueue(this);

        //fetch rankings
        fetchRankings();

        //button listener
        submitButton.setOnClickListener(v -> {
            if (searchBar.getText().toString().isEmpty()) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                RadioButton selectedButton = findViewById(selectedId);
                selectedTeam = selectedButton.getText().toString().split("\\) ")[1];
            } else {
                selectedTeam = searchBar.getText().toString();
            }

            Intent intent = new Intent(MainActivity.this, TeamDataActivity.class);
            intent.putExtra("team", selectedTeam);
            startActivity(intent);
        });
    }

    //gets the rankings for the home page
    private void fetchRankings() {
        String url = "https://cuddly-happiness-7g79vj96rv3xj79-8080.app.github.dev/api/rankings";

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray ranks = response.getJSONObject(0) //parses the JSON data
                                .getJSONArray("polls")
                                .getJSONObject(0)
                                .getJSONArray("ranks");

                        for (int i = 0; i < 25; i++) { //prints the ranked teams
                            JSONObject rank = ranks.getJSONObject(i);
                            String team = rank.getString("school");
                            RadioButton button = new RadioButton(this);
                            button.setText((i + 1) + ") " + team);
                            radioGroup.addView(button);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> error.printStackTrace()
        );

        requestQueue.add(request);
    }
}