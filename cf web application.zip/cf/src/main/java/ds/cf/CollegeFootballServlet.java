//Miles Maltbia
//mmaltbia

package ds.cf;

import com.mongodb.client.result.InsertOneResult;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.bson.json.JsonWriterSettings;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.mongodb.client.*;

@WebServlet("/api/*")
public class CollegeFootballServlet extends HttpServlet {

    private static final String API_KEY = "EjEn2w7M3mTHCrpqa15HDxC1biPfAiPidagcgmLSG+8e1oozLa6kQw05PyKpkVN+";
    public static String CONNECTION_STRING = "mongodb+srv://mmaltbia:Milesjered2@cluster0.bo93m.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    @Override
    public void init() throws ServletException {
        super.init();
        mongoClient = MongoClients.create(CONNECTION_STRING); //connects to the mongo db
        database = mongoClient.getDatabase("CLuster0");
        collection = database.getCollection("searches");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { //parses the path/url
        String path = req.getPathInfo();
        if (path == null) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            System.out.println("Path: " + path);
            resp.getWriter().write("Invalid request path");
            return;
        }

        if(path.equals("/teams")){
            handleGetTeams(resp);
        } else if (path.equals("/rankings")){
            handleGetRankings(resp);
        } else if(path.startsWith("/team/")){
            String teamName = path.substring(6);
            handleGetTeamData(teamName, resp);
        } else if(path.equals("/mongodata")){
            handleGetMongoInfo(resp);
        } else {
            resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
            resp.getWriter().write("Invalid endpoint");
        }
    }

    private void handleGetTeams(HttpServletResponse resp) throws IOException {
        String TEAMS_API_URL = "https://api.collegefootballdata.com/teams"; //connects to cf api
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TEAMS_API_URL))
                .header("Authorization", "Bearer " + API_KEY)
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String jsonString = response.body();
            writeJson(resp, jsonString); //uses writeJson method to send response
        } catch (InterruptedException | IOException e) {
            Logger.getLogger(CollegeFootballServlet.class.getName()).log(Level.SEVERE, "Error fetching teams", e); //handles errors
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("Error fetching teams");
        }
    }

    private void handleGetRankings(HttpServletResponse resp) throws IOException { //gets the ranked teams from the api
        String RANKINGS_API_URL = "https://api.collegefootballdata.com/rankings?year=2024&week=13&seasonType=regular";
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(RANKINGS_API_URL))
                .header("Authorization", "Bearer " + API_KEY)
                .build();

        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String jsonString = response.body();
            writeJson(resp, jsonString); //uses writeJson method to send response
        } catch (InterruptedException | IOException e) {
            Logger.getLogger(CollegeFootballServlet.class.getName()).log(Level.SEVERE, "Error fetching rankings", e); //handles errors
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("Error fetching rankings");
        }
    }

    private void handleGetTeamData(String teamName, HttpServletResponse resp) throws IOException {
        String final_team_name = teamName.replace("_", " "); //so it seaarchs for "carnegie mellon" not "carnegie_mellon"
        String TEAMS_API_URL = "https://api.collegefootballdata.com/teams";
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder() //connects tot he api
                .uri(URI.create(TEAMS_API_URL))
                .header("Authorization", "Bearer " + API_KEY)
                .build();
        System.out.println("Connected to API");
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            JSONArray teams = new JSONArray(response.body());
            System.out.println("Loaded all teams");
            boolean teamFound = false;
            JSONObject teamData = null;
            for (int i = 0; i < teams.length(); i++) {
                JSONObject team = teams.getJSONObject(i);
                String schoolName = team.getString("school");
                String alt1 = "noneX";
                String alt2 = "noneX";
                String alt3 = "noneX";
                if(team.get("alt_name1") != JSONObject.NULL) { //makes sure the alternative team names are valid and not null
                    System.out.println("Alt1: " + team.get("alt_name1") + ", Type: " + team.get("alt_name1").getClass());
                    alt1 = team.getString("alt_name1");
                }
                if(team.get("alt_name2") != JSONObject.NULL) {
                    System.out.println("Alt2: " + team.get("alt_name2"));
                    alt2 = team.getString("alt_name2");
                }
                if(team.get("alt_name3") != JSONObject.NULL) {
                    System.out.println("Alt3: " + team.get("alt_name3"));
                    alt3 = team.getString("alt_name3");
                }
                if (schoolName.equalsIgnoreCase(final_team_name) || alt1.equalsIgnoreCase(final_team_name) || alt2.equalsIgnoreCase(final_team_name) || alt3.equalsIgnoreCase(final_team_name)) { //searches through all team names and all alternative team names
                    System.out.println(teamName + " found!");
                    teamFound = true;
                    teamData = team;
                    System.out.println("Team: " + team.get("school") == JSONObject.NULL ? null : team.get("school")); //gets all of the JSON data
                    System.out.println("Conference: " + team.get("conference") == JSONObject.NULL ? null : team.get("conference"));
                    System.out.println("Classification: " + team.get("classification") == JSONObject.NULL ? null : team.get("classification"));
                    System.out.println("State: " + team.getJSONObject("location").get("state") == JSONObject.NULL ? null : team.getJSONObject("location").get("state"));
                    System.out.println("Capacity: " + team.getJSONObject("location").get("capacity") == JSONObject.NULL ? null : team.getJSONObject("location").get("capacity"));
                    System.out.println("Year Constructed: " + team.getJSONObject("location").get("year_constructed") == JSONObject.NULL ? null : team.getJSONObject("location").get("year_constructed"));
                    System.out.println("Country Code: " + team.getJSONObject("location").get("country_code") == JSONObject.NULL ? null : team.getJSONObject("location").get("country_code"));
                    System.out.println("Grass: " + team.getJSONObject("location").get("grass") == JSONObject.NULL ? null : team.getJSONObject("location").get("grass"));
                    System.out.println("Timezone: " + team.getJSONObject("location").get("timezone") == JSONObject.NULL ? null : team.getJSONObject("location").get("timezone"));
                    System.out.println("Timestamp: " + new Timestamp(System.currentTimeMillis()));
                    System.out.println("Capacity: " + team.getJSONObject("location").get("capacity") + ", Type: " + team.getJSONObject("location").get("capacity").getClass());
                    Document document = new Document() //adds this search to the mongodb
                            .append("team", (team.get("school") == JSONObject.NULL ? null : team.get("school")))
                            .append("conference", (team.get("conference") == JSONObject.NULL ? null : team.get("conference")))
                            .append("classification", (team.get("classification") == JSONObject.NULL ? null : team.get("classification")))
                            .append("state", (team.getJSONObject("location").get("state") == JSONObject.NULL ? null : team.getJSONObject("location").get("state")))
                            .append("capacity", (team.getJSONObject("location").get("capacity") == JSONObject.NULL ? null : team.getJSONObject("location").get("capacity")))
                            .append("year_constructed", (team.getJSONObject("location").get("year_constructed") == JSONObject.NULL ? null : team.getJSONObject("location").get("year_constructed")))
                            .append("country_code", (team.getJSONObject("location").get("country_code") == JSONObject.NULL ? null : team.getJSONObject("location").get("country_code")))
                            .append("grass", (team.getJSONObject("location").get("grass") == JSONObject.NULL ? null : team.getJSONObject("location").get("grass")))
                            .append("timezone", (team.getJSONObject("location").get("timezone") == JSONObject.NULL ? null : team.getJSONObject("location").get("timezone")))
                            .append("timestamp", new Timestamp(System.currentTimeMillis()));
                    collection.insertOne(document); // Save data to MongoDB
                    System.out.println(teamName + " saved to MongoDB");
                    break; // Exit loop once team is found
                }
            }

            if (teamFound) { //error handling
                writeJson(resp, teamData.toString()); // Send team data as JSON response
            } else {
                writeJson(resp, new JSONObject("No Team Found!").toString()); // Send "No Team Found" message
            }

        } catch (InterruptedException | IOException | JSONException e) { //error handling
            Logger.getLogger(CollegeFootballServlet.class.getName()).log(Level.SEVERE, "Error fetching team data", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("Error fetching team data");
        }
    }

    private void handleGetMongoInfo(HttpServletResponse resp) throws IOException { //returns the info about every team searched
        JSONArray result = new JSONArray();
        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                JSONObject jo = new JSONObject(doc.toJson());
                result.put(jo);
            }

            writeJson(resp, result.toString()); // Send JSON response with retrieved data
        } catch (JSONException e) { //error handling
            Logger.getLogger(CollegeFootballServlet.class.getName()).log(Level.SEVERE, "Error retrieving data from MongoDB", e);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("Error retrieving data from MongoDB");
        }
    }

    private void writeJson(HttpServletResponse resp, String jsonString) throws IOException { //helper method to convert to JSON
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(jsonString);
    }
}